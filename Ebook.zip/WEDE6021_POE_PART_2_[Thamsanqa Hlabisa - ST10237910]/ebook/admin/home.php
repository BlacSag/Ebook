<?php
session_start();
include("includes/head.inc.php");
include("includes/header.php");
?>