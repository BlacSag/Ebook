<!DOCTYPE html>
<html lang="en">
<head>
	<title>Document</title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../css/bootstrap.min-3.3.7.css">
	<link rel="stylesheet" href="../css/font-awesome.min.css">
	<link rel="stylesheet" href="../css/style.css">

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">


	<link rel="stylesheet" href="style.css">
</head>
<body>


	

	<!--================ Start Header Menu Area =================-->
	<div class="head">
		
			<div class="row">
				<div class="col-md-2">
					<h2>Admin</h2>
				</div>
				<div class=" col-md-offset-2 col-md-6">
					<h2>Online Book Shop Management System</h2>
				</div>
				<div class="col-md-2">
					<a href="../logout.php"><button class="btn btn-primary ct">Sign out</button></a>
				</div>
			</div>
		
	</div>
	<!--================ End Header Menu Area =================-->
	<!--================ Admin part Start =================-->
	
		<div class="col-md-2 admin">

			<ul>
				<li><a href="home.php">Dashboard</a></li>
				<li><a href="#">User</a></li>
				<li><a href="bookdetails.php">Book</a></li>
				
				<li><a href="pend.php">Pending Order</a></li>
				
				
				<li><a href="confirm.php">cash on delivery order</a></li>	
				
			</ul>
		</div>
	<!--================ Admin part end =================-->






	
	<!--img start-->
	

	<script src="../js/jquery-3.2.1.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	
	
</body>
</html>