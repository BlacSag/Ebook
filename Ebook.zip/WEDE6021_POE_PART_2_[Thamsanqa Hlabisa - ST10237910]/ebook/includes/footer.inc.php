
<div class="footer">
<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="col-md-6 about">
					<h2>About</h2>
					<p>Phone : 03554150019</p>
					<p>Email : CampusThrift@workmail.com</p>
					<p>Address: Durban CBD</p>
				</div>
			</div>
		</div>
	</div>
</div>
<link rel="stylesheet" type="text/css" href="css/styles.css">

<p class='footer'>
	&copy 2023 All rights reserved.
</p>